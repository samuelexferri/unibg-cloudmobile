exports.mongoose = require('mongoose')
exports.google-trends-api = require('google-trends-api')